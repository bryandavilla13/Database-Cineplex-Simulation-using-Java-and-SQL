-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2023 at 06:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `proyekbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `film`
--

CREATE TABLE `film` (
  `id` int(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `durasi` int(10) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `sutradara` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `film`
--

INSERT INTO `film` (`id`, `nama`, `durasi`, `genre`, `sutradara`) VALUES
(1, 'The Flash', 144, 'Action', 'Andrés Muschietti'),
(2, 'Transformers: Rise of the Beasts', 127, 'Sci-fi', 'Steven Caple Jr.'),
(3, 'Elemental', 109, 'Animation', 'Peter Sohn'),
(4, 'The Little Mermaid', 135, 'Fantasy', 'Rob Marshall'),
(5, 'Onde Mande!', 97, 'Comedy', 'Paul Agusta'),
(6, 'The Boogeyman', 98, 'Horror', 'Rob Savage'),
(7, 'SOSOK KETIGA', 99, 'Horror', 'Dedy Mercy'),
(8, 'The Childe', 118, 'Adventure', 'Park Hoon-jung'),
(9, 'Hypnotic', 99, 'Thriller', 'Robert Rodriguez');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id` int(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int(20) NOT NULL,
  `jumlah_uang` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id`, `nama`, `email`, `number`, `jumlah_uang`) VALUES
(1, 'Bryan Ozora', 'ozora123@gmail.com', 62728491, 10000000),
(2, 'Christopher Boenadhi', 'bundan456@gmail.com', 816283912, 9000000),
(3, 'Bryan Davila', 'c14220079@john.petra.ac.id', 898293809, 8000000),
(4, 'Louis Margatan', 'louismargatan23@gmail.com', 856129478, 9500000),
(5, 'Aurum Gunawan', 'agun456@gmail.com', 856254947, 9750000),
(6, 'Endang Setyati', 'endangkorea@gmail.com', 856258947, 10000000),
(7, 'Sari Gracia', 'graciasari@gmail.com', 871838193, 7500000),
(8, 'Hanbok Jigmi', '好久不见 @gmail.com', 872838193, 8500000);

-- --------------------------------------------------------

--
-- Table structure for table `studio`
--

CREATE TABLE `studio` (
  `id` int(20) NOT NULL,
  `jumlah_kursi` int(20) NOT NULL,
  `theatre_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studio`
--

INSERT INTO `studio` (`id`, `jumlah_kursi`, `theatre_id`) VALUES
(1, 224, 1),
(2, 250, 1),
(3, 260, 1),
(4, 280, 1),
(5, 150, 1),
(6, 170, 1),
(7, 200, 2),
(8, 250, 2),
(9, 288, 2),
(10, 234, 2),
(11, 250, 2),
(12, 156, 3),
(13, 190, 3),
(14, 225, 3),
(15, 250, 3),
(16, 248, 3),
(17, 200, 4),
(18, 225, 4),
(19, 235, 4),
(20, 150, 4),
(21, 180, 4),
(22, 190, 4),
(23, 167, 5),
(24, 190, 5),
(25, 225, 5),
(26, 250, 5),
(27, 235, 5),
(28, 289, 5);

-- --------------------------------------------------------

--
-- Table structure for table `theatre`
--

CREATE TABLE `theatre` (
  `id` int(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `kota` varchar(20) NOT NULL,
  `jumlah_studio` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `theatre`
--

INSERT INTO `theatre` (`id`, `nama`, `alamat`, `kota`, `jumlah_studio`) VALUES
(1, 'CinemaXXI', 'Jalan Tunjungan 1 ', 'Surabaya', 8),
(2, 'Cinepolis', 'Jalan Ahmad Yani 10 ', 'Surabaya', 6),
(3, 'CGVXXI', 'Jalan Maspion 56', 'Surabaya', 6),
(4, 'CineplexXXI', 'Jalan Graha Family 67', 'Surabaya', 10),
(5, 'Galaxy XXI', 'Jl. Siwalankerto No.121-131', 'Surabaya', 8),
(6, 'qda', '123132', '1233', 123);

-- --------------------------------------------------------

--
-- Table structure for table `tiket`
--

CREATE TABLE `tiket` (
  `id` int(10) NOT NULL,
  `tanggal` date NOT NULL,
  `harga` int(20) NOT NULL,
  `pengguna_id` int(10) NOT NULL,
  `transaksi_id` int(10) NOT NULL,
  `theatre_id` int(10) NOT NULL,
  `studio_id` int(10) NOT NULL,
  `film_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tiket`
--

INSERT INTO `tiket` (`id`, `tanggal`, `harga`, `pengguna_id`, `transaksi_id`, `theatre_id`, `studio_id`, `film_id`) VALUES
(1, '2023-06-25', 45000, 2, 4, 5, 28, 1),
(2, '2023-06-24', 100000, 3, 5, 5, 24, 3),
(3, '2023-06-22', 40000, 1, 10, 2, 21, 6),
(4, '2003-12-22', 30000, 1, 10, 2, 2, 1),
(5, '2023-04-23', 40000, 6, 14, 3, 13, 4),
(6, '2023-04-25', 46000, 7, 13, 1, 4, 7),
(7, '2023-04-20', 55000, 8, 10, 3, 16, 9),
(8, '2023-05-17', 60000, 5, 6, 5, 23, 2),
(9, '2023-05-19', 65000, 8, 7, 4, 18, 5),
(11, '2023-05-22', 75000, 8, 3, 2, 11, 8),
(12, '2023-05-26', 80000, 3, 5, 2, 10, 6),
(13, '2023-02-04', 100000, 6, 3, 2, 7, 5),
(14, '2023-02-06', 100000, 4, 6, 3, 15, 1),
(15, '2023-02-09', 100000, 4, 8, 2, 8, 4);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(10) NOT NULL,
  `tanggal` date NOT NULL,
  `nominal` int(20) NOT NULL,
  `pengguna_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `tanggal`, `nominal`, `pengguna_id`) VALUES
(1, '2015-06-17', 20000, 5),
(2, '2020-06-12', 7650, 1),
(3, '2013-06-12', 40000, 2),
(4, '1913-06-12', 42000, 1),
(5, '2016-06-09', 12334, 2),
(6, '2000-03-12', 135334, 3),
(7, '2025-06-18', 40000, 3),
(8, '2022-06-18', 54200, 1),
(9, '2031-06-03', 122341, 5),
(10, '2021-06-23', 12244, 1),
(11, '2024-06-12', 20000, 1),
(12, '2014-06-22', 51000, 2),
(13, '2031-06-18', 20000, 2),
(14, '2021-09-18', 41200, 5),
(15, '2005-06-01', 12334, 1),
(18, '2023-06-26', 150000, 8),
(19, '2023-06-26', 150000, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studio`
--
ALTER TABLE `studio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `theatre_id` (`theatre_id`);

--
-- Indexes for table `theatre`
--
ALTER TABLE `theatre`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tiket`
--
ALTER TABLE `tiket`
  ADD PRIMARY KEY (`id`),
  ADD KEY `film_id` (`film_id`),
  ADD KEY `pengguna_id` (`pengguna_id`),
  ADD KEY `studio_id` (`studio_id`),
  ADD KEY `theatre_id` (`theatre_id`),
  ADD KEY `transaksi_id` (`transaksi_id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengguna_id` (`pengguna_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `film`
--
ALTER TABLE `film`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `studio`
--
ALTER TABLE `studio`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `theatre`
--
ALTER TABLE `theatre`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tiket`
--
ALTER TABLE `tiket`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `studio`
--
ALTER TABLE `studio`
  ADD CONSTRAINT `studio_ibfk_1` FOREIGN KEY (`theatre_id`) REFERENCES `theatre` (`id`);

--
-- Constraints for table `tiket`
--
ALTER TABLE `tiket`
  ADD CONSTRAINT `tiket_ibfk_1` FOREIGN KEY (`film_id`) REFERENCES `film` (`id`),
  ADD CONSTRAINT `tiket_ibfk_2` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`),
  ADD CONSTRAINT `tiket_ibfk_3` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`id`),
  ADD CONSTRAINT `tiket_ibfk_4` FOREIGN KEY (`theatre_id`) REFERENCES `theatre` (`id`),
  ADD CONSTRAINT `tiket_ibfk_5` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

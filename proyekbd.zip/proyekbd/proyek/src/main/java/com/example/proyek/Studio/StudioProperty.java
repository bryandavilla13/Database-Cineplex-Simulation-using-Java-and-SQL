package com.example.proyek.Studio;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class StudioProperty {
   private final StringProperty id;
   private final StringProperty jumlahKursi;
   private final StringProperty theatreId;

   public StudioProperty(){
      id = new SimpleStringProperty(this, "id");
      jumlahKursi = new SimpleStringProperty(this, "jumlah_kursi");
      theatreId = new SimpleStringProperty(this, "theatre_id");
   }

   public StringProperty IdProperty(){return id;}
   public String getId(){return IdProperty().get();}
   public void setId(String newId){id.set(newId);}

   public StringProperty JumlahKursiProperty(){return jumlahKursi;}
   public String getJumlahKursiProperty(){return JumlahKursiProperty().get();}
   public void setJumlahKursi(String newJumlahKursi){jumlahKursi.set(newJumlahKursi);}

   public StringProperty TheatreIdProperty(){return theatreId;}
   public String getTheatreId(){return TheatreIdProperty().get();}
   public void setTheatreId(String newTheatreId){theatreId.set(newTheatreId);}
}

package com.example.proyek;

import com.example.proyek.Film.Film;
import com.example.proyek.Film.FilmProperty;
import com.example.proyek.Film.FilmRepository;
import com.example.proyek.HelloApplication;
import com.example.proyek.Pagination;
import com.example.proyek.Pengguna.Pengguna;
import com.example.proyek.Pengguna.PenggunaProperty;
import com.example.proyek.Pengguna.PenggunaRepository;
import com.example.proyek.Transaksi.Transaksi;
import com.example.proyek.Transaksi.TransaksiProperty;
import com.example.proyek.Transaksi.TransaksiRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Analisis implements Initializable{
   @FXML
   Label nominal;
   private TransaksiRepository transaksiRepository = new TransaksiRepository();
   @FXML
   private TableColumn<PenggunaProperty, String> ColumnId, ColumnNama, ColumnEmail, ColumnNumber, ColumnJumlahUang;
   @FXML
   private TableColumn<FilmProperty, String> ColumnFilmId, ColumnFilmNama, ColumnDurasi, ColumnGenre, ColumnSutradara;
   @FXML
   private TableView<PenggunaProperty> TableViewPengguna;
   @FXML
   private TableView<FilmProperty> TableViewFilm;
   private int page = 1;
   private int rowsPerPage = 3;
   private ObservableList<PenggunaProperty> penggunas = FXCollections.observableArrayList();
   private ObservableList<FilmProperty> films = FXCollections.observableArrayList();
   private PenggunaRepository penggunaRepository = new PenggunaRepository();
   private FilmRepository filmRepository = new FilmRepository();

   public Analisis() throws SQLException {
   }

   @FXML
   void onBackButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getMenu());
   }

   @FXML
   void onRefreshButtonClick() throws SQLException {
      nominal.setText(transaksiRepository.getNominal(new Pagination(1,1)));
      updateTable();
   }

   public void updateTable() throws SQLException{
      penggunas = FXCollections.observableArrayList();
      ArrayList<Pengguna> result;
      try {
         result = penggunaRepository.GetMostBuy(new Pagination(page, rowsPerPage));
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      result.forEach((p) -> {
         PenggunaProperty pt = new PenggunaProperty();
         pt.setId(Integer.toString(p.id));
         pt.setNama(p.nama);
         pt.setEmail(p.email);
         pt.setNumber(Integer.toString(p.number));
         pt.setJumlahUang(Integer.toString(p.jumlah_uang));
         penggunas.add(pt);
      });
      TableViewPengguna.setItems(penggunas);

      films = FXCollections.observableArrayList();
      ArrayList<Film> resultFilm;
      try {
         resultFilm = filmRepository.GetMostFilm(new Pagination(page, rowsPerPage));
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      resultFilm.forEach((f) -> {
         FilmProperty ft = new FilmProperty();
         ft.setId(Integer.toString(f.id));
         ft.setNama(f.nama);
         ft.setDurasi(Integer.toString(f.durasi));
         ft.setGenre(f.genre);
         ft.setSutradara(f.sutradara);
         films.add(ft);
      });
      TableViewFilm.setItems(films);
   }

   @Override
   public void initialize(URL url, ResourceBundle resourceBundle) {
      try {
         nominal.setText(transaksiRepository.getNominal(new Pagination(1,1)));
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      ColumnId.setCellValueFactory(f -> f.getValue().IdProperty());
      ColumnNama.setCellValueFactory(f -> f.getValue().NamaProperty());
      ColumnEmail.setCellValueFactory(f -> f.getValue().EmailProperty());
      ColumnNumber.setCellValueFactory(f -> f.getValue().NumberProperty());
      ColumnJumlahUang.setCellValueFactory(f -> f.getValue().JumlahUangProperty());
      try {
         updateTable();
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      ColumnFilmId.setCellValueFactory(f -> f.getValue().IdProperty());
      ColumnFilmNama.setCellValueFactory(f -> f.getValue().NamaProperty());
      ColumnDurasi.setCellValueFactory(f -> f.getValue().DurasiProperty());
      ColumnGenre.setCellValueFactory(f -> f.getValue().GenreProperty());
      ColumnSutradara.setCellValueFactory(f -> f.getValue().SutradaraProperty());
      try {
         updateTable();
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }
}


package com.example.proyek.Pengguna;

import com.example.proyek.HelloApplication;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class PenggunaDelete {
   @FXML
   TextField id;
   boolean isValid;
   @FXML
   Label warningText;
   PenggunaRepository penggunaRepository;

   @FXML
   public void onDeleteButtonClick() throws SQLException {
      penggunaRepository = new PenggunaRepository();
      String inputId = id.getText().replace(" ","");
      isValid = true;
      if (inputId.contains(",")){
         String[] temp = inputId.split(",");
         for (String x : temp) {
            if (penggunaRepository.cekId(Integer.parseInt(x)) && isValid) {
               penggunaRepository.deleteData(Integer.parseInt(x));
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getPenggunaController().updateTable();
            app.setPrimaryStage(app.getPengguna());
         }
      }
      else if (inputId.contains("-")){
         String[] temp = inputId.split("-");
         for (int i = Integer.parseInt(temp[0]) ; i <= Integer.parseInt(temp[1]) ; i++){
            if (penggunaRepository.cekId(i) && isValid) {
               penggunaRepository.deleteData(i);
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getPenggunaController().updateTable();
            app.setPrimaryStage(app.getPengguna());
         }
      }
      else {
         if (penggunaRepository.cekId(Integer.parseInt(id.getText()))){
            penggunaRepository.deleteData(Integer.parseInt(id.getText()));
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getPenggunaController().updateTable();
            app.setPrimaryStage(app.getPengguna());
         }
         else {
            warningText.setText("Input Invalid");
         }
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getPengguna());
   }
}
package com.example.proyek.Film;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pengguna.PenggunaRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class FilmUpdate {

   @FXML
   TextField id, nama, durasi, genre, sutradara;
   @FXML
   Label warningText;
   FilmRepository filmRepository;

   @FXML
   public void onEditButtonClick() throws SQLException {
      filmRepository = new FilmRepository();
      if (!isNumeric(id.getText())){
         warningText.setText("Id harus angka");
      }
      else if (!filmRepository.cekId(Integer.parseInt(id.getText()))){
         warningText.setText("Id invalid");
      }
      else {
         filmRepository.updateData(Integer.parseInt(id.getText()), nama.getText(), Integer.parseInt(durasi.getText()), genre.getText(), sutradara.getText());
         HelloApplication app = HelloApplication.getapplicationInstance();
         app.getFilmController().updateTable();
         app.setPrimaryStage(app.getFilm());
      }
   }

   public static boolean isNumeric(String s){
      try {
         Double.parseDouble(s);
         return true;
      } catch (NumberFormatException e){
         return false;
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getFilm());
   }
}

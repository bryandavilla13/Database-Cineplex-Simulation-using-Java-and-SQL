package com.example.proyek.Theatre;

public class Theatre {
   int id, jumlahStudio;
   String nama, alamat, kota;

   public Theatre(int id, String nama, String alamat, String kota, int jumlah_studio) {
      this.id = id;
      this.nama = nama;
      this.alamat = alamat;
      this.kota = kota;
      this.jumlahStudio = jumlah_studio;
   }
}

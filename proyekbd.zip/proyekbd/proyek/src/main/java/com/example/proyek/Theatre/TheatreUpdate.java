package com.example.proyek.Theatre;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pengguna.PenggunaRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.sql.SQLException;

public class TheatreUpdate {
   @FXML
   TextField id, nama, alamat, kota, jumlahStudio;
   @FXML
   Label warningText;
   TheatreRepository theatreRepository;

   @FXML
   public void onEditButtonClick() throws SQLException {
      theatreRepository = new TheatreRepository();
      if (!isNumeric(id.getText())){
         warningText.setText("Id harus angka");
      }
      else if (!isNumeric(jumlahStudio.getText())){
         warningText.setText("Jumlah Studio harus angka");
      }
      else if (!theatreRepository.cekId(Integer.parseInt(id.getText()))){
         warningText.setText("Id invalid");
      }
      else {
         theatreRepository.updateData(Integer.parseInt(id.getText()), nama.getText(), alamat.getText(), kota.getText(), Integer.parseInt(jumlahStudio.getText()));
         HelloApplication app = HelloApplication.getapplicationInstance();
         app.getTheatreController().updateTable();
         app.setPrimaryStage(app.getTheatre());
      }
   }

   public static boolean isNumeric(String s){
      try {
         Double.parseDouble(s);
         return true;
      } catch (NumberFormatException e){
         return false;
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getTheatre());
   }
}

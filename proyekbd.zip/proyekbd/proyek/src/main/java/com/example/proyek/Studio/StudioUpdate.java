package com.example.proyek.Studio;

import com.example.proyek.HelloApplication;
import com.example.proyek.Transaksi.TransaksiRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

public class StudioUpdate {
   @FXML
   TextField id, jumlahKursi, theatreId;
   boolean isValid;
   @FXML
   Label warningText;
   StudioRepository studioRepository;

   @FXML
   public void onEditButtonClick() throws SQLException {
      studioRepository = new StudioRepository();
      if (!isNumeric(id.getText())){
         warningText.setText("Id harus angka");
      }
      else if (!isNumeric(jumlahKursi.getText())){
         warningText.setText("jumlah kursi harus angka");
      }
      else if (!isNumeric(theatreId.getText())){
         warningText.setText("theatre id harus angka");
      }
      else {
         isValid = true;
         try{
            studioRepository.updateData(Integer.parseInt(id.getText()), Integer.parseInt(jumlahKursi.getText()), Integer.parseInt(theatreId.getText()));
         } catch (SQLIntegrityConstraintViolationException e){
            warningText.setText("theatre ID Tidak ditemukan");
            isValid = false;
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getStudioController().updateTable();
            app.setPrimaryStage(app.getStudio());
         }
      }
   }

   public static boolean isNumeric(String s){
      try {
         Double.parseDouble(s);
         return true;
      } catch (NumberFormatException e){
         return false;
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getStudio());
   }
}

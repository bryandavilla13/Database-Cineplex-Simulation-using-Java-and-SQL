package com.example.proyek.Tiket;

import com.example.proyek.Film.Film;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class TiketProperty {
   private final StringProperty id, tanggal, harga, penggunaId, transaksiId, theatreId, studioId, filmId;

   public TiketProperty() {
      id = new SimpleStringProperty(this, "id");
      tanggal = new SimpleStringProperty(this, "tanggal");
      harga = new SimpleStringProperty(this, "harga");
      penggunaId = new SimpleStringProperty(this, "pengguna_id");
      transaksiId = new SimpleStringProperty(this, "transaksi_id");
      theatreId = new SimpleStringProperty(this, "theatre_id");
      studioId = new SimpleStringProperty(this, "studio_id");
      filmId = new SimpleStringProperty(this, "film_id");
   }

   public StringProperty IdProperty(){return id;}
   public String getId(){return IdProperty().get();}
   public void setId(String newId){id.set(newId);}

   public StringProperty TanggalProperty(){return tanggal;}
   public String getTanggal(){return TanggalProperty().get();}
   public void setTanggal(String newTanggal){tanggal.set(newTanggal);}

   public StringProperty HargaProperty(){return harga;}
   public String getHarga(){return HargaProperty().get();}
   public void setHarga(String newHarga){harga.set(newHarga);}

   public StringProperty PenggunaIdProperty(){return penggunaId;}
   public String getPenggunaId(){return PenggunaIdProperty().get();}
   public void setPenggunaId(String newPenggunaId){penggunaId.set(newPenggunaId);}

   public StringProperty TransaksiIdProperty(){return transaksiId;}
   public String getTransaksiId(){return TransaksiIdProperty().get();}
   public void setTransaksiId(String newTransaksiId){transaksiId.set(newTransaksiId);}

   public StringProperty TheatreIdProperty(){return theatreId;}
   public String getTheatreId(){return TheatreIdProperty().get();}
   public void setTheatreId(String newTheatreId){theatreId.set(newTheatreId);}

   public StringProperty StudioIdProperty(){return studioId;}
   public String getStudioId(){return StudioIdProperty().get();}
   public void setStudioId(String newStudioId){studioId.set(newStudioId);}

   public StringProperty FilmIdProperty(){return filmId;}
   public String getFilmId(){return FilmIdProperty().get();}
   public void setFilmId(String newFilmId){filmId.set(newFilmId);}
}

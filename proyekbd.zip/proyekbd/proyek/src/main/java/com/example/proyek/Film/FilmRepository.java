package com.example.proyek.Film;

import com.example.proyek.Pagination;
import com.example.proyek.Pengguna.Pengguna;
import com.example.proyek.connection;

import java.sql.*;
import java.time.temporal.JulianFields;
import java.util.ArrayList;

public class FilmRepository {
   private Connection conn;

   public FilmRepository() throws SQLException {
      conn = connection.GetConnection();
   }

   public int GetFilmCount() throws SQLException {
      Statement stmt = conn.createStatement();
      String sql = "SELECT COUNT(id) FROM film";
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      if(rs.next()){
         return rs.getInt(1);
      } else{
         return 0;
      }
   }

   public ArrayList<Film> GetFilm(Pagination pgn) throws SQLException {
      ArrayList<Film> films = new ArrayList<Film>();
      Statement stmt = conn.createStatement();
      String sql = String.format("SELECT * FROM film LIMIT %o OFFSET %o", pgn.limit, pgn.offset);
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()){
         films.add(
                 new Film(
                         rs.getInt("id"),
                         rs.getString("nama"),
                         rs.getInt("durasi"),
                         rs.getString("genre"),
                         rs.getString("sutradara")
                 )
         );
      }
      return films;
   }

   public void insertData(String nama, int durasi, String genre, String sutradara) {
      String Query = "INSERT INTO film (nama, durasi, genre, sutradara) VALUES (?,?,?,?)";
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         preparedStatement.setString(1, nama);
         preparedStatement.setString(2, String.valueOf(durasi));
         preparedStatement.setString(3, genre);
         preparedStatement.setString(4, sutradara);

         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e)
      {
         System.out.println(e);
      }
   }

   public void updateData(int id, String nama, int durasi, String genre, String sutradara) {
      String Query = "UPDATE film SET ";
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query + "nama = '" + nama + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();
         preparedStatement = conn.prepareStatement(Query + "durasi = '" + durasi + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();
         preparedStatement = conn.prepareStatement(Query + "genre = '" + genre + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();
         preparedStatement = conn.prepareStatement(Query + "sutradara = '" + sutradara + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();

         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e)
      {
         System.out.println(e);
      }
   }

   public void deleteData(int id){
      String Query = "DELETE FROM film WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e)
      {
         System.out.println(e);
      }
   }

   public boolean cekId(int id){
      String Query = "select * FROM film WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e) {
         return false;
      }
      return true;
   }

   public ArrayList<Film> GetMostFilm(Pagination pgn) throws SQLException {
      ArrayList<Film> films = new ArrayList<Film>();
      Statement stmt = conn.createStatement();
      String sql = String.format("SELECT f.id, f.nama, f.durasi, f.genre, f.sutradara\n" +
              "FROM film f\n" +
              "join tiket t on t.film_id = f.id\n" +
              "GROUP by f.id\n" +
              "ORDER BY count(t.id) DESC LIMIT %o OFFSET %o", pgn.limit, pgn.offset);
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()){
         films.add(
                 new Film(
                         rs.getInt("id"),
                         rs.getString("nama"),
                         rs.getInt("durasi"),
                         rs.getString("genre"),
                         rs.getString("sutradara")
                 )
         );
      }
      return films;
   }
}

package com.example.proyek.Pengguna;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pagination;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class PenggunaController implements Initializable {
   @FXML
   private Button ButtonNext, ButtonPrev;
   @FXML
   private TableColumn<PenggunaProperty, String> ColumnId, ColumnNama, ColumnEmail, ColumnNumber, ColumnJumlahUang;
   @FXML
   private TableView<PenggunaProperty> TableViewPengguna;

   private int page = 1;

   private int rowsPerPage = 12;

   private ObservableList<PenggunaProperty> penggunas = FXCollections.observableArrayList();

   private PenggunaRepository penggunaRepository = new PenggunaRepository();

   public PenggunaController() throws SQLException {
   }

   @FXML
   void onNextButtonClick(ActionEvent event) throws SQLException {
      page++;
      updateTable();
   }

   @FXML
   void onPrevButtonClick(ActionEvent event) throws SQLException {
      page--;
      updateTable();
   }

   @FXML
   void onBackButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getMenu());
   }

   @FXML
   void onAddButtonClick(){
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.setPrimaryStage(app.getPenggunaInsert());
   }

   @FXML
   void onEditButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getPenggunaUpdate());
   }

   @FXML
   void onDeleteButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getPenggunaDelete());
   }

   private void updateButton() throws SQLException {
      if(page <= 1){
         ButtonPrev.setDisable(true);
      } else {
         ButtonPrev.setDisable(false);
      }
      if (page >= Math.ceil((penggunaRepository.GetPenggunaCount() / Double.valueOf(rowsPerPage)))){
         ButtonNext.setDisable(true);
      } else {
         ButtonNext.setDisable(false);
      }
   }

   public void updateTable() throws SQLException {
      penggunas = FXCollections.observableArrayList();
      ArrayList<Pengguna> result;
      try {
         result = penggunaRepository.GetPengguna(new Pagination(page, rowsPerPage));
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      result.forEach((p) -> {
         PenggunaProperty pt = new PenggunaProperty();
         pt.setId(Integer.toString(p.id));
         pt.setNama(p.nama);
         pt.setEmail(p.email);
         pt.setNumber(Integer.toString(p.number));
         pt.setJumlahUang(Integer.toString(p.jumlah_uang));
         penggunas.add(pt);
      });
      TableViewPengguna.setItems(penggunas);
      updateButton();
   }

   @Override
   public void initialize(URL url, ResourceBundle resourceBundle) {
      ColumnId.setCellValueFactory(f -> f.getValue().IdProperty());
      ColumnNama.setCellValueFactory(f -> f.getValue().NamaProperty());
      ColumnEmail.setCellValueFactory(f -> f.getValue().EmailProperty());
      ColumnNumber.setCellValueFactory(f -> f.getValue().NumberProperty());
      ColumnJumlahUang.setCellValueFactory(f -> f.getValue().JumlahUangProperty());
      try {
         updateTable();
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }
}
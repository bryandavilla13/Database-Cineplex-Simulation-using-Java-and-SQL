package com.example.proyek.Pengguna;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class PenggunaProperty {
   private final StringProperty id;
   private final StringProperty nama;
   private final StringProperty email;
   private final StringProperty number;
   private final StringProperty jumlahUang;

   public PenggunaProperty(){
      id = new SimpleStringProperty(this, "id");
      nama = new SimpleStringProperty(this, "nama");
      email = new SimpleStringProperty(this, "email");
      number = new SimpleStringProperty(this, "number");
      jumlahUang = new SimpleStringProperty(this, "jumlah_uang");
   }

   public StringProperty IdProperty(){return id;}
   public String getId(){return IdProperty().get();}
   public void setId(String newId){id.set(newId);}

   public StringProperty NamaProperty(){return nama;}
   public String getNama(){return NamaProperty().get();}
   public void setNama(String newNama){nama.set(newNama);}

   public StringProperty EmailProperty(){return email;}
   public String getEmail(){return EmailProperty().get();}
   public void setEmail(String newEmail){email.set(newEmail);}

   public StringProperty NumberProperty(){return number;}
   public String getNumber(){return NumberProperty().get();}
   public void setNumber(String newNumber){number.set(newNumber);}

   public StringProperty JumlahUangProperty(){return jumlahUang;}
   public String getJumlahUang(){return JumlahUangProperty().get();}
   public void setJumlahUang(String newJumlahUang){jumlahUang.set(newJumlahUang);}
}

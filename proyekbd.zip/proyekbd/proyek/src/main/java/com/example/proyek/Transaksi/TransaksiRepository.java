package com.example.proyek.Transaksi;

import com.example.proyek.Pagination;
import com.example.proyek.connection;

import java.sql.*;
import java.time.temporal.JulianFields;
import java.util.ArrayList;

public class TransaksiRepository {
   private Connection conn;

   public TransaksiRepository() throws SQLException {
      conn = connection.GetConnection();
   }

   public int GetTransaksiCount() throws SQLException {
      Statement stmt = conn.createStatement();
      String sql = "SELECT COUNT(id) FROM transaksi";
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      if(rs.next()){
         return rs.getInt(1);
      } else{
         return 0;
      }
   }

   public ArrayList<Transaksi> GetTransaksi(Pagination pgn) throws SQLException {
      ArrayList<Transaksi> transaksis = new ArrayList<Transaksi>();
      Statement stmt = conn.createStatement();
      String sql = String.format("SELECT * FROM transaksi LIMIT %o OFFSET %o", pgn.limit, pgn.offset);
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()){
         transaksis.add(
                 new Transaksi(
                         rs.getInt("id"),
                         rs.getString("tanggal"),
                         rs.getInt("nominal"),
                         rs.getInt("pengguna_id")
                 )
         );
      }
      return transaksis;
   }

   public void insertData(String tanggal, int nominal, int pengguna_id) throws SQLException {
      String Query = "INSERT INTO transaksi (tanggal, nominal, pengguna_id) VALUES (?,?,?)";
      PreparedStatement preparedStatement = conn.prepareStatement(Query);
      preparedStatement.setString(1, tanggal);
      preparedStatement.setString(2, Integer.toString(nominal));
      preparedStatement.setString(3, Integer.toString(pengguna_id));
      System.out.println(preparedStatement);
      preparedStatement.execute();
   }

   public void updateData(int id, String tanggal, int nominal, int pengguna_id) throws SQLException {
      String Query = "UPDATE transaksi SET ";
      PreparedStatement preparedStatement = conn.prepareStatement(Query + "tanggal = '" + tanggal + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
      preparedStatement = conn.prepareStatement(Query + "nominal = '" + nominal + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
      preparedStatement = conn.prepareStatement(Query + "pengguna_id = '" + pengguna_id + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
   }
   public void deleteData(int id) throws SQLException {
      String Query = "DELETE FROM transaksi WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e)
      {
         System.out.println(e);
      }
   }

   public boolean cekId(int id) throws SQLException {
      String Query = "select * FROM transaksi WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e) {
         return false;
      }
      return true;
   }

   public String getNominal(Pagination pgn) throws SQLException {
      Statement stmt = conn.createStatement();
      String sql = String.format("SELECT sum(nominal) FROM transaksi LIMIT %o OFFSET %o", pgn.limit, pgn.offset);
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      rs.next();
      return rs.getString("sum(nominal)");
   }
}

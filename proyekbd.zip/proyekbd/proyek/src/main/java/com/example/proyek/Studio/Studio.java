package com.example.proyek.Studio;

public class Studio {
   int id, jumlahKursi, theatreId;

   public Studio(int id, int jumlahKursi, int theatreId) {
      this.id = id;
      this.jumlahKursi = jumlahKursi;
      this.theatreId = theatreId;
   }
}

package com.example.proyek.Film;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pagination;
import com.example.proyek.Pengguna.Pengguna;
import com.example.proyek.Pengguna.PenggunaProperty;
import com.example.proyek.Pengguna.PenggunaRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class FilmController implements Initializable {
   @FXML
   private Button ButtonNext, ButtonPrev;
   @FXML
   private TableColumn<FilmProperty, String> ColumnId, ColumnNama, ColumnDurasi, ColumnGenre, ColumnSutradara;
   @FXML
   private TableView<FilmProperty> TableViewFilm;

   private int page = 1;

   private int rowsPerPage = 12;

   private ObservableList<FilmProperty> films = FXCollections.observableArrayList();

   private FilmRepository filmRepository = new FilmRepository();

   public FilmController() throws SQLException {
   }

   @FXML
   void onNextButtonClick(ActionEvent event) throws SQLException {
      page++;
      updateTable();
   }

   @FXML
   void onPrevButtonClick(ActionEvent event) throws SQLException {
      page--;
      updateTable();
   }

   @FXML
   void onBackButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getMenu());
   }

   @FXML
   void onAddButtonClick(){
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.setPrimaryStage(app.getFilmInsert());
   }

   @FXML
   void onEditButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getFilmUpdate());
   }

   @FXML
   void onDeleteButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getFilmDelete());
   }

   private void updateButton() throws SQLException {
      if(page <= 1){
         ButtonPrev.setDisable(true);
      } else {
         ButtonPrev.setDisable(false);
      }
      if (page >= Math.ceil((filmRepository.GetFilmCount() / Double.valueOf(rowsPerPage)))){
         ButtonNext.setDisable(true);
      } else {
         ButtonNext.setDisable(false);
      }
   }

   public void updateTable() throws SQLException {
      films = FXCollections.observableArrayList();
      ArrayList<Film> result;
      try {
         result = filmRepository.GetFilm(new Pagination(page, rowsPerPage));
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      result.forEach((f) -> {
         FilmProperty ft = new FilmProperty();
         ft.setId(Integer.toString(f.id));
         ft.setNama(f.nama);
         ft.setDurasi(Integer.toString(f.durasi));
         ft.setGenre(f.genre);
         ft.setSutradara(f.sutradara);
         films.add(ft);
      });
      TableViewFilm.setItems(films);
      updateButton();
   }

   @Override
   public void initialize(URL url, ResourceBundle resourceBundle) {
      ColumnId.setCellValueFactory(f -> f.getValue().IdProperty());
      ColumnNama.setCellValueFactory(f -> f.getValue().NamaProperty());
      ColumnDurasi.setCellValueFactory(f -> f.getValue().DurasiProperty());
      ColumnGenre.setCellValueFactory(f -> f.getValue().GenreProperty());
      ColumnSutradara.setCellValueFactory(f -> f.getValue().SutradaraProperty());
      try {
         updateTable();
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }

}

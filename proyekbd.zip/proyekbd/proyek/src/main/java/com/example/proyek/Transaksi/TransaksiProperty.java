package com.example.proyek.Transaksi;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class TransaksiProperty {
   private final StringProperty id;
   private final StringProperty tanggal;
   private final StringProperty nominal;
   private final StringProperty penggunaId;

   public TransaksiProperty(){
      id = new SimpleStringProperty(this, "id");
      tanggal = new SimpleStringProperty(this, "tanggal");
      nominal = new SimpleStringProperty(this, "nominal");
      penggunaId = new SimpleStringProperty(this, "pengguna_id");
   }

   public StringProperty IdProperty(){return id;}
   public String getId(){return IdProperty().get();}
   public void setId(String newId){id.set(newId);}

   public StringProperty TanggalProperty(){return tanggal;}
   public String getTanggal(){return TanggalProperty().get();}
   public void setTanggal(String newTanggal){tanggal.set(newTanggal);}

   public StringProperty NominalProperty(){return nominal;}
   public String getNominal(){return NominalProperty().get();}
   public void setNominal(String newNominal){nominal.set(newNominal);}

   public StringProperty PenggunaIdProperty(){return penggunaId;}
   public String getPenggunaId(){return PenggunaIdProperty().get();}
   public void setPenggunaId(String newPenggunaId){penggunaId.set(newPenggunaId);}
}

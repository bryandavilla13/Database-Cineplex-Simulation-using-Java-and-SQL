package com.example.proyek.Film;

public class Film {
   public int id;
   public int durasi;
   public String nama;
   public String genre;
   public String sutradara;

   public Film(int id, String nama, int durasi, String genre, String sutradara) {
      this.id = id;
      this.nama = nama;
      this.durasi = durasi;
      this.genre = genre;
      this.sutradara = sutradara;
   }
}

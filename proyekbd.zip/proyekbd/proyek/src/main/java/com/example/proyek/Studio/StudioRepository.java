package com.example.proyek.Studio;

import com.example.proyek.Pagination;
import com.example.proyek.Transaksi.Transaksi;
import com.example.proyek.connection;

import java.sql.*;
import java.util.ArrayList;

public class StudioRepository {
   private Connection conn;

   public StudioRepository() throws SQLException {
      conn = connection.GetConnection();
   }

   public int GetStudioCount() throws SQLException {
      Statement stmt = conn.createStatement();
      String sql = "SELECT COUNT(id) FROM studio";
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      if(rs.next()){
         return rs.getInt(1);
      } else{
         return 0;
      }
   }

   public ArrayList<Studio> GetStudio(Pagination pgn) throws SQLException {
      ArrayList<Studio> studios = new ArrayList<Studio>();
      Statement stmt = conn.createStatement();
      String sql = String.format("SELECT * FROM studio LIMIT %o OFFSET %o", pgn.limit, pgn.offset);
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()){
         studios.add(
                 new Studio(
                         rs.getInt("id"),
                         rs.getInt("jumlah_kursi"),
                         rs.getInt("theatre_id")
                 )
         );
      }
      return studios;
   }

   public void insertData(int jumlahKursi, int theatreId) throws SQLException {
      String Query = "INSERT INTO studio (jumlah_kursi, theatre_id) VALUES (?,?)";
      PreparedStatement preparedStatement = conn.prepareStatement(Query);
      preparedStatement.setString(1, Integer.toString(jumlahKursi));
      preparedStatement.setString(2, Integer.toString(theatreId));
      System.out.println(preparedStatement);
      preparedStatement.execute();
   }

   public void updateData(int id, int jumlahKursi, int theatreId) throws SQLException {
      String Query = "UPDATE studio SET ";
      PreparedStatement preparedStatement = conn.prepareStatement(Query + "jumlah_kursi = '" + jumlahKursi + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
      preparedStatement = conn.prepareStatement(Query + "theatre_id = '" + theatreId + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
   }
   public void deleteData(int id) throws SQLException {
      String Query = "DELETE FROM studio WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e)
      {
         System.out.println(e);
      }
   }

   public boolean cekId(int id) throws SQLException {
      String Query = "select * FROM studio WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e) {
         return false;
      }
      return true;
   }
}

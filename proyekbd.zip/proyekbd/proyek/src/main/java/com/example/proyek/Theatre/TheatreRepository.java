package com.example.proyek.Theatre;

import com.example.proyek.Pagination;
import com.example.proyek.Pengguna.Pengguna;
import com.example.proyek.connection;

import java.sql.*;
import java.time.temporal.JulianFields;
import java.util.ArrayList;

public class TheatreRepository {
   private Connection conn;

   public TheatreRepository() throws SQLException{
      conn = connection.GetConnection();
   }

   public int GetTheatreCount() throws SQLException {
      Statement stmt = conn.createStatement();
      String sql = "SELECT COUNT(id) FROM theatre";
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      if(rs.next()){
         return rs.getInt(1);
      } else{
         return 0;
      }
   }

   public ArrayList<Theatre> GetTheatre(Pagination pgn) throws SQLException {
      ArrayList<Theatre> theatres = new ArrayList<Theatre>();
      Statement stmt = conn.createStatement();
      String sql = String.format("SELECT * FROM theatre LIMIT %o OFFSET %o", pgn.limit, pgn.offset);
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()){
         theatres.add(
                 new Theatre(
                         rs.getInt("id"),
                         rs.getString("nama"),
                         rs.getString("alamat"),
                         rs.getString("kota"),
                         rs.getInt("jumlah_studio")
                 )
         );
      }
      return theatres;
   }

   public void insertData(String nama, String alamat, String kota, int jumlahStudio) {
      String Query = "INSERT INTO theatre (nama, alamat, kota, jumlah_studio) VALUES (?,?,?,?)";
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         preparedStatement.setString(1, nama);
         preparedStatement.setString(2, alamat);
         preparedStatement.setString(3, kota);
         preparedStatement.setString(4, String.valueOf(jumlahStudio));

         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e)
      {
         System.out.println(e);
      }
   }

   public void updateData(int id, String nama, String alamat, String kota, int jumlahStudio) {
      String Query = "UPDATE theatre SET ";
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query + "nama = '" + nama + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();
         preparedStatement = conn.prepareStatement(Query + "alamat = '" + alamat + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();
         preparedStatement = conn.prepareStatement(Query + "kota = '" + kota + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();
         preparedStatement = conn.prepareStatement(Query + "jumlah_studio = '" + jumlahStudio + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();

         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e)
      {
         System.out.println(e);
      }
   }

   public void deleteData(int id){
      String Query = "DELETE FROM theatre WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e)
      {
         System.out.println(e);
      }
   }

   public boolean cekId(int id){
      String Query = "select * FROM theatre WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e) {
         return false;
      }
      return true;
   }
}

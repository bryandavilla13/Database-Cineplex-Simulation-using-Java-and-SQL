package com.example.proyek.Transaksi;

public class Transaksi {
   int id, nominal, penggunaId;
   String tanggal;

   public Transaksi(int id, String tanggal, int nominal, int penggunaId) {
      this.id = id;
      this.nominal = nominal;
      this.tanggal = tanggal;
      this.penggunaId = penggunaId;
   }

}

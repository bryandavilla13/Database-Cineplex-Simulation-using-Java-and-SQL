package com.example.proyek;

import com.example.proyek.Film.FilmController;
import com.example.proyek.Film.FilmDelete;
import com.example.proyek.Film.FilmInsert;
import com.example.proyek.Film.FilmUpdate;
import com.example.proyek.Pengguna.*;
import com.example.proyek.Studio.StudioController;
import com.example.proyek.Studio.StudioDelete;
import com.example.proyek.Studio.StudioInsert;
import com.example.proyek.Studio.StudioUpdate;
import com.example.proyek.Theatre.TheatreController;
import com.example.proyek.Theatre.TheatreDelete;
import com.example.proyek.Theatre.TheatreInsert;
import com.example.proyek.Theatre.TheatreUpdate;
import com.example.proyek.Tiket.TiketController;
import com.example.proyek.Tiket.TiketDelete;
import com.example.proyek.Tiket.TiketInsert;
import com.example.proyek.Tiket.TiketUpdate;
import com.example.proyek.Transaksi.TransaksiController;
import com.example.proyek.Transaksi.TransaksiDelete;
import com.example.proyek.Transaksi.TransaksiInsert;
import com.example.proyek.Transaksi.TransaksiUpdate;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
   private Stage primaryStage;
   private Scene menu, analisis;
   private Scene pengguna, penggunaInsert, penggunaUpdate, PenggunaDelete;
   private Scene theatre, theatreInsert, theatreUpdate, theatreDelete;
   private Scene film, filmInsert, filmUpdate, filmDelete;
   private Scene transaksi, transaksiInsert, transaksiUpdate, transaksiDelete;
   private Scene tiket, tiketInsert, tiketUpdate, tiketDelete;
   private Scene studio, studioInsert, studioUpdate, studioDelete;
   private PenggunaController penggunaController;
   private PenggunaInsert penggunaInsertController;
   private PenggunaUpdate penggunaUpdateController;
   private PenggunaDelete penggunaDeleteController;
   private TheatreController theatreController;
   private TheatreInsert theatreInsertController;
   private TheatreUpdate theatreUpdateController;
   private TheatreDelete theatreDeleteController;
   private FilmController filmController;
   private FilmInsert filmInsertController;
   private FilmUpdate filmUpdateController;
   private FilmDelete filmDeleteController;
   private TransaksiController transaksiController;
   private TransaksiInsert transaksiInsertController;
   private TransaksiUpdate transaksiUpdateController;
   private TransaksiDelete transaksiDeleteController;
   private StudioController studioController;
   private StudioInsert studioInsertController;
   private StudioUpdate studioUpdateController;
   private StudioDelete studioDeleteController;
   private TiketController tiketController;
   private TiketInsert tiketInsertController;
   private TiketUpdate tiketUpdateController;
   private TiketDelete tiketDeleteController;

   private Analisis analisisController;

   public Stage getPrimaryStage() {
      return primaryStage;
   }

   public void setPrimaryStage(Scene scene){
      this.primaryStage.setScene(scene);
   }

   public Scene getMenu() {
      return menu;
   }

   public Scene getPengguna() {
      return pengguna;
   }

   public PenggunaController getPenggunaController() {
      return penggunaController;
   }

   public Scene getPenggunaInsert() {
      return penggunaInsert;
   }

   public PenggunaInsert getPenggunaInsertController() {
      return penggunaInsertController;
   }

   public Scene getPenggunaUpdate() {
      return penggunaUpdate;
   }

   public PenggunaUpdate getPenggunaUpdateController() {
      return penggunaUpdateController;
   }

   public Scene getPenggunaDelete() {
      return PenggunaDelete;
   }

   public com.example.proyek.Pengguna.PenggunaDelete getPenggunaDeleteController() {
      return penggunaDeleteController;
   }

   public Scene getTheatre() {
      return theatre;
   }

   public Scene getTheatreInsert() {
      return theatreInsert;
   }

   public Scene getTheatreUpdate() {
      return theatreUpdate;
   }

   public Scene getTheatreDelete() {
      return theatreDelete;
   }

   public TheatreController getTheatreController() {
      return theatreController;
   }

   public TheatreInsert getTheatreInsertController() {
      return theatreInsertController;
   }

   public TheatreUpdate getTheatreUpdateController() {
      return theatreUpdateController;
   }

   public TheatreDelete getTheatreDeleteController() {
      return theatreDeleteController;
   }

   public Scene getTransaksi() {
      return transaksi;
   }

   public Scene getTransaksiInsert() {
      return transaksiInsert;
   }

   public Scene getTransaksiUpdate() {
      return transaksiUpdate;
   }

   public Scene getTransaksiDelete() {
      return transaksiDelete;
   }

   public TransaksiController getTransaksiController() {
      return transaksiController;
   }

   public TransaksiInsert getTransaksiInsertController() {
      return transaksiInsertController;
   }

   public TransaksiUpdate getTransaksiUpdateController() {
      return transaksiUpdateController;
   }

   public TransaksiDelete getTransaksiDeleteController() {
      return transaksiDeleteController;
   }

   public Scene getTiket() {
      return tiket;
   }

   public Scene getTiketInsert() {
      return tiketInsert;
   }

   public Scene getTiketUpdate() {
      return tiketUpdate;
   }

   public Scene getTiketDelete() {
      return tiketDelete;
   }

   public TiketController getTiketController() {
      return tiketController;
   }

   public TiketInsert getTiketInsertController() {
      return tiketInsertController;
   }

   public TiketUpdate getTiketUpdateController() {
      return tiketUpdateController;
   }

   public TiketDelete getTiketDeleteController() {
      return tiketDeleteController;
   }

   public Scene getStudio() {
      return studio;
   }

   public Scene getStudioInsert() {
      return studioInsert;
   }

   public Scene getStudioUpdate() {
      return studioUpdate;
   }

   public Scene getStudioDelete() {
      return studioDelete;
   }

   public StudioController getStudioController() {
      return studioController;
   }

   public StudioInsert getStudioInsertController() {
      return studioInsertController;
   }

   public StudioUpdate getStudioUpdateController() {
      return studioUpdateController;
   }

   public StudioDelete getStudioDeleteController() {
      return studioDeleteController;
   }

   public Scene getFilm() {
      return film;
   }

   public Scene getFilmInsert() {
      return filmInsert;
   }

   public Scene getFilmUpdate() {
      return filmUpdate;
   }

   public Scene getFilmDelete() {
      return filmDelete;
   }

   public FilmController getFilmController() {
      return filmController;
   }

   public FilmInsert getFilmInsertController() {
      return filmInsertController;
   }

   public FilmUpdate getFilmUpdateController() {
      return filmUpdateController;
   }

   public FilmDelete getFilmDeleteController() {
      return filmDeleteController;
   }


   public Scene getAnalisis() {
      return analisis;
   }

   public Analisis getAnalisisController() {
      return analisisController;
   }

   public static HelloApplication getApplicationInstance() {
      return applicationInstance;
   }

   private static HelloApplication applicationInstance;

   public HelloApplication() {
      applicationInstance = this;
   }

   public static HelloApplication getapplicationInstance() {
      return applicationInstance;
   }

   @Override
   public void start(Stage stage) throws IOException {
      this.primaryStage = stage;

      FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Menu.fxml"));
      menu = new Scene(fxmlLoader.load(), 600, 550);

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Pengguna/pengguna.fxml"));
      pengguna = new Scene(fxmlLoader.load(), 600, 500);
      penggunaController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Pengguna/PenggunaInsert.fxml"));
      penggunaInsert = new Scene(fxmlLoader.load(), 600, 500);
      penggunaInsertController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Pengguna/PenggunaUpdate.fxml"));
      penggunaUpdate = new Scene(fxmlLoader.load(), 600, 500);
      penggunaUpdateController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Pengguna/PenggunaDelete.fxml"));
      PenggunaDelete = new Scene(fxmlLoader.load(), 600, 500);
      penggunaDeleteController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Theatre/theatre.fxml"));
      theatre = new Scene(fxmlLoader.load(), 600, 500);
      theatreController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Theatre/TheatreInsert.fxml"));
      theatreInsert = new Scene(fxmlLoader.load(), 600, 500);
      theatreInsertController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Theatre/TheatreUpdate.fxml"));
      theatreUpdate = new Scene(fxmlLoader.load(), 600, 500);
      theatreUpdateController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Theatre/TheatreDelete.fxml"));
      theatreDelete = new Scene(fxmlLoader.load(), 600, 500);
      theatreDeleteController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Film/film.fxml"));
      film = new Scene(fxmlLoader.load(), 600, 500);
      filmController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Film/FilmInsert.fxml"));
      filmInsert = new Scene(fxmlLoader.load(), 600, 500);
      filmInsertController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Film/FilmUpdate.fxml"));
      filmUpdate = new Scene(fxmlLoader.load(), 600, 500);
      filmUpdateController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Film/FilmDelete.fxml"));
      filmDelete = new Scene(fxmlLoader.load(), 600, 500);
      filmDeleteController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Transaksi/transaksi.fxml"));
      transaksi = new Scene(fxmlLoader.load(), 600, 500);
      transaksiController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Transaksi/TransaksiInsert.fxml"));
      transaksiInsert = new Scene(fxmlLoader.load(), 600, 500);
      transaksiInsertController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Transaksi/TransaksiUpdate.fxml"));
      transaksiUpdate = new Scene(fxmlLoader.load(), 600, 500);
      transaksiUpdateController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Transaksi/TransaksiDelete.fxml"));
      transaksiDelete = new Scene(fxmlLoader.load(), 600, 500);
      transaksiDeleteController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Studio/studio.fxml"));
      studio = new Scene(fxmlLoader.load(), 600, 500);
      studioController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Studio/StudioInsert.fxml"));
      studioInsert = new Scene(fxmlLoader.load(), 600, 500);
      studioInsertController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Studio/StudioUpdate.fxml"));
      studioUpdate = new Scene(fxmlLoader.load(), 600, 500);
      studioUpdateController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Studio/StudioDelete.fxml"));
      studioDelete = new Scene(fxmlLoader.load(), 600, 500);
      studioDeleteController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Tiket/tiket.fxml"));
      tiket = new Scene(fxmlLoader.load(), 700, 500);
      tiketController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Tiket/TiketInsert.fxml"));
      tiketInsert = new Scene(fxmlLoader.load(), 600, 500);
      tiketInsertController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Tiket/TiketUpdate.fxml"));
      tiketUpdate = new Scene(fxmlLoader.load(), 600, 500);
      tiketUpdateController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Tiket/TiketDelete.fxml"));
      tiketDelete = new Scene(fxmlLoader.load(), 600, 500);
      tiketDeleteController = fxmlLoader.getController();

      fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Analisis.fxml"));
      analisis = new Scene(fxmlLoader.load(), 600, 500);
      analisisController = fxmlLoader.getController();

      stage.setTitle("PROYEK DATABASE");
      stage.setScene(menu);
      stage.show();
   }

   public static void main(String[] args) {
      launch();
   }
}
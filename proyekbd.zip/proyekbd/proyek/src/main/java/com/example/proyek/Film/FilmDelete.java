package com.example.proyek.Film;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pengguna.PenggunaRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class FilmDelete {
   @FXML
   TextField id;
   boolean isValid = false;
   @FXML
   Label warningText;
   FilmRepository filmRepository;

   @FXML
   public void onDeleteButtonClick() throws SQLException {
      filmRepository = new FilmRepository();
      String inputId = id.getText().replace(" ","");
      isValid = true;
      if (inputId.contains(",")){
         String[] temp = inputId.split(",");
         for (String x : temp) {
            if (filmRepository.cekId(Integer.parseInt(x)) && isValid) {
               filmRepository.deleteData(Integer.parseInt(x));
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getFilmController().updateTable();
            app.setPrimaryStage(app.getFilm());
         }
      }
      else if (inputId.contains("-")){
         String[] temp = inputId.split("-");
         for (int i = Integer.parseInt(temp[0]) ; i <= Integer.parseInt(temp[1]) ; i++){
            if (filmRepository.cekId(i) && isValid) {
               filmRepository.deleteData(i);
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getFilmController().updateTable();
            app.setPrimaryStage(app.getFilm());
         }
      }
      else {
         if (filmRepository.cekId(Integer.parseInt(id.getText()))){
            filmRepository.deleteData(Integer.parseInt(id.getText()));
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getFilmController().updateTable();
            app.setPrimaryStage(app.getFilm());
         }
         else {
            warningText.setText("Input Invalid");
         }
      }
   }

   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getFilm());
   }
}

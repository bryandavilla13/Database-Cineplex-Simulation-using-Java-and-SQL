package com.example.proyek.Studio;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pagination;
import com.example.proyek.Transaksi.Transaksi;
import com.example.proyek.Transaksi.TransaksiProperty;
import com.example.proyek.Transaksi.TransaksiRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class StudioController implements Initializable{
   @FXML
   private Button ButtonNext, ButtonPrev;
   @FXML
   private TableColumn<StudioProperty, String> ColumnId, ColumnJumlahKursi, ColumnTheatreId;
   @FXML
   private TableView<StudioProperty> TableViewStudio;

   private int page = 1;

   private int rowsPerPage = 12;

   private ObservableList<StudioProperty> studios = FXCollections.observableArrayList();

   private StudioRepository studioRepository = new StudioRepository();

   public StudioController() throws SQLException {
   }

   @FXML
   void onNextButtonClick(ActionEvent event) throws SQLException {
      page++;
      updateTable();
   }

   @FXML
   void onPrevButtonClick(ActionEvent event) throws SQLException {
      page--;
      updateTable();
   }

   @FXML
   void onBackButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getMenu());
   }

   @FXML
   void onAddButtonClick(){
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.setPrimaryStage(app.getStudioInsert());
   }

   @FXML
   void onEditButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getStudioUpdate());
   }

   @FXML
   void onDeleteButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getStudioDelete());
   }

   private void updateButton() throws SQLException {
      if(page <= 1){
         ButtonPrev.setDisable(true);
      } else {
         ButtonPrev.setDisable(false);
      }
      if (page >= Math.ceil((studioRepository.GetStudioCount() / Double.valueOf(rowsPerPage)))){
         ButtonNext.setDisable(true);
      } else {
         ButtonNext.setDisable(false);
      }
   }

   public void updateTable() throws SQLException {
      studios = FXCollections.observableArrayList();
      ArrayList<Studio> result;
      try {
         result = studioRepository.GetStudio(new Pagination(page, rowsPerPage));
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      result.forEach((t) -> {
         StudioProperty tp = new StudioProperty();
         tp.setId(Integer.toString(t.id));
         tp.setJumlahKursi(Integer.toString(t.jumlahKursi));
         tp.setTheatreId(Integer.toString(t.theatreId));
         studios.add(tp);
      });
      TableViewStudio.setItems(studios);
      updateButton();
   }

   @Override
   public void initialize(URL url, ResourceBundle resourceBundle) {
      ColumnId.setCellValueFactory(f -> f.getValue().IdProperty());
      ColumnJumlahKursi.setCellValueFactory(f -> f.getValue().JumlahKursiProperty());
      ColumnTheatreId.setCellValueFactory(f -> f.getValue().TheatreIdProperty());
      try {
         updateTable();
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }
}

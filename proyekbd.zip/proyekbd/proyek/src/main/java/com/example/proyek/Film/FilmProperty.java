package com.example.proyek.Film;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class FilmProperty {
   private final StringProperty id;
   private final StringProperty nama;
   private final StringProperty durasi;
   private final StringProperty genre;
   private final StringProperty sutradara;

   public FilmProperty() {
      id = new SimpleStringProperty(this, "id");
      nama = new SimpleStringProperty(this, "nama");
      durasi = new SimpleStringProperty(this, "durasi");
      genre = new SimpleStringProperty(this, "genre");
      sutradara = new SimpleStringProperty(this, "sutradara");
   }

   public StringProperty IdProperty(){return id;}
   public String getId(){return IdProperty().get();}
   public void setId(String newId){id.set(newId);}

   public StringProperty NamaProperty(){return nama;}
   public String getNama(){return NamaProperty().get();}
   public void setNama(String newNama){nama.set(newNama);}

   public StringProperty DurasiProperty(){return durasi;}
   public String getDurasi(){return DurasiProperty().get();}
   public void setDurasi(String newDurasi){durasi.set(newDurasi);}

   public StringProperty GenreProperty(){return genre;}
   public String getGenre(){return GenreProperty().get();}
   public void setGenre(String newGenre){genre.set(newGenre);}

   public StringProperty SutradaraProperty(){return sutradara;}
   public String getSutradara(){return SutradaraProperty().get();}
   public void setSutradara(String newSutradara){sutradara.set(newSutradara);}
}

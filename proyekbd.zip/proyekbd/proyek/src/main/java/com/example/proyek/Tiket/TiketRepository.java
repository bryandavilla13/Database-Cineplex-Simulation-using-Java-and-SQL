package com.example.proyek.Tiket;

import com.example.proyek.Pagination;
import com.example.proyek.Transaksi.Transaksi;
import com.example.proyek.connection;

import java.sql.*;
import java.time.temporal.JulianFields;
import java.util.ArrayList;

public class TiketRepository {

   private Connection conn;

   public TiketRepository() throws SQLException {
      conn = connection.GetConnection();
   }

   public int GetTiketCount() throws SQLException {
      Statement stmt = conn.createStatement();
      String sql = "SELECT COUNT(id) FROM tiket";
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      if(rs.next()){
         return rs.getInt(1);
      } else{
         return 0;
      }
   }

   public ArrayList<Tiket> GetTiket (Pagination pgn) throws SQLException {
      ArrayList<Tiket> tikets = new ArrayList<Tiket>();
      Statement stmt = conn.createStatement();
      String sql = String.format("SELECT * FROM tiket LIMIT %o OFFSET %o", pgn.limit, pgn.offset);
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()){
         tikets.add(
                 new Tiket(
                         rs.getInt("id"),
                         rs.getString("tanggal"),
                         rs.getInt("harga"),
                         rs.getInt("pengguna_id"),
                         rs.getInt("transaksi_id"),
                         rs.getInt("theatre_id"),
                         rs.getInt("studio_id"),
                         rs.getInt("film_id")
                 )
         );
      }
      return tikets;
   }

   public void insertData(String tanggal, int harga, int pengguna_id, int transaksi_id, int theatre_id, int studio_id, int film_id) throws SQLException {
      String Query = "INSERT INTO tiket (tanggal, harga, pengguna_id, transaksi_id, theatre_id, studio_id, film_id) VALUES (?,?,?,?,?,?,?)";
      PreparedStatement preparedStatement = conn.prepareStatement(Query);
      preparedStatement.setString(1, tanggal);
      preparedStatement.setString(2, Integer.toString(harga));
      preparedStatement.setString(3, Integer.toString(pengguna_id));
      preparedStatement.setString(4, Integer.toString(transaksi_id));
      preparedStatement.setString(5, Integer.toString(theatre_id));
      preparedStatement.setString(6, Integer.toString(studio_id));
      preparedStatement.setString(7, Integer.toString(film_id));
      System.out.println(preparedStatement);
      preparedStatement.execute();
   }

   public void updateData(int id, String tanggal, int harga, int pengguna_id, int transaksi_id, int theatre_id, int studio_id, int film_id) throws SQLException {
      String Query = "UPDATE tiket SET ";
      PreparedStatement preparedStatement = conn.prepareStatement(Query + "tanggal = '" + tanggal + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
      preparedStatement = conn.prepareStatement(Query + "harga = '" + harga + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
      preparedStatement = conn.prepareStatement(Query + "pengguna_id = '" + pengguna_id + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
      preparedStatement = conn.prepareStatement(Query + "transaksi_id = '" + transaksi_id + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
      preparedStatement = conn.prepareStatement(Query + "theatre_id = '" + theatre_id + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
      preparedStatement = conn.prepareStatement(Query + "studio_id = '" + studio_id + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
      preparedStatement = conn.prepareStatement(Query + "film_id = '" + film_id + "' where id = " + id);
      System.out.println(preparedStatement);
      preparedStatement.execute();
   }

   public void deleteData(int id) throws SQLException {
      String Query = "DELETE FROM tiket WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e)
      {
         System.out.println(e);
      }
   }

   public boolean cekId(int id) throws SQLException {
      String Query = "select * FROM tiket WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e) {
         return false;
      }
      return true;
   }
}


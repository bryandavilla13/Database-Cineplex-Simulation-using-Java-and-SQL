package com.example.proyek.Transaksi;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pengguna.PenggunaRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class TransaksiDelete {
   @FXML
   TextField id;
   boolean isValid;
   @FXML
   Label warningText;
   TransaksiRepository transaksiRepository;

   @FXML
   public void onDeleteButtonClick() throws SQLException {
      transaksiRepository = new TransaksiRepository();
      String inputId = id.getText().replace(" ","");
      isValid = true;
      if (inputId.contains(",")){
         String[] temp = inputId.split(",");
         for (String x : temp) {
            if (transaksiRepository.cekId(Integer.parseInt(x)) && isValid) {
               transaksiRepository.deleteData(Integer.parseInt(x));
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getTransaksiController().updateTable();
            app.setPrimaryStage(app.getTransaksi());
         }
      }
      else if (inputId.contains("-")){
         String[] temp = inputId.split("-");
         for (int i = Integer.parseInt(temp[0]) ; i <= Integer.parseInt(temp[1]) ; i++){
            if (transaksiRepository.cekId(i) && isValid) {
               transaksiRepository.deleteData(i);
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getTransaksiController().updateTable();
            app.setPrimaryStage(app.getTransaksi());
         }
      }
      else {
         if (transaksiRepository.cekId(Integer.parseInt(id.getText()))){
            transaksiRepository.deleteData(Integer.parseInt(id.getText()));
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getTransaksiController().updateTable();
            app.setPrimaryStage(app.getTransaksi());
         }
         else {
            warningText.setText("Input Invalid");
         }
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getTransaksi());
   }
}

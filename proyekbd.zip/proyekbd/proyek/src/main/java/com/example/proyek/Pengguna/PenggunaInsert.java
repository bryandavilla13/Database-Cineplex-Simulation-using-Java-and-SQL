package com.example.proyek.Pengguna;

import com.example.proyek.HelloApplication;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class PenggunaInsert {
   @FXML
   TextField nama, email, number, jumlahUang;
   @FXML
   Label warningText;
   PenggunaRepository penggunaRepository;

   @FXML
   public void onAddButtonClick() throws SQLException {
      penggunaRepository = new PenggunaRepository();
      if (!isNumeric(number.getText())){
         warningText.setText("Number harus angka");
      }
      else if (!isNumeric(jumlahUang.getText()) || jumlahUang.getText().equals("")){
         warningText.setText("jumlah uang harus angka");
      }
      else {
         penggunaRepository.insertData(nama.getText(), email.getText(), Integer.parseInt(number.getText()), Integer.parseInt(jumlahUang.getText()));
         HelloApplication app = HelloApplication.getapplicationInstance();
         app.getPenggunaController().updateTable();
         app.setPrimaryStage(app.getPengguna());
      }
   }

   public static boolean isNumeric(String s){
      try {
         Double.parseDouble(s);
         return true;
      } catch (NumberFormatException e){
         return false;
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getPengguna());
   }
}

package com.example.proyek.Tiket;

import com.example.proyek.HelloApplication;
import com.example.proyek.Transaksi.TransaksiRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

public class TiketInsert {
   @FXML
   TextField tanggal, harga, penggunaId, transaksiId, theatreId, studioId, filmId;
   boolean isValid;
   @FXML
   Label warningText;
   TiketRepository tiketRepository;

   @FXML
   public void onAddButtonClick() throws SQLException {
      tiketRepository = new TiketRepository();
      if (!isNumeric(penggunaId.getText())){
         warningText.setText("Pengguna ID harus angka");
      }
      else if (!isNumeric(transaksiId.getText())){
         warningText.setText("Transaksi ID harus angka");
      }
      else if (!isNumeric(theatreId.getText())){
         warningText.setText("Theatre ID harus angka");
      }
      else if (!isNumeric(studioId.getText())){
         warningText.setText("Studio ID harus angka");
      }
      else if (!isNumeric(filmId.getText())){
         warningText.setText("Film ID harus angka");
      }
      else if (!(tanggal.getText().length() == 10)){
         warningText.setText("Tanggal Invalid");
      }
      else if (!(tanggal.getText().charAt(4) == '-')){
         warningText.setText("Tanggal Invalid");
      }
      else if (!(tanggal.getText().charAt(7) == '-')){
         warningText.setText("Tanggal Invalid");
      }
      else {
         String[] temp = tanggal.getText().split("-");
         String tanggalAkhir = "";
         for (String s : temp) {
            if (!isNumeric(s)) {
               warningText.setText("Tanggal Invalid");
            }
         }
         if (temp.length != 3){
            warningText.setText("Tanggal Invalid");
         }
         else if (Integer.parseInt(temp[1]) > 12 || Integer.parseInt(temp[1]) < 0){
            warningText.setText("Bulan Invalid");
         }
         else if (Integer.parseInt(temp[2]) > 31 || Integer.parseInt(temp[2]) < 0){
            warningText.setText("Bulan Invalid");
         }
         else {
            tanggalAkhir += temp[0] + "-" + temp[1] + "-" + temp[2];
            isValid = true;
            try {
               tiketRepository.insertData(tanggalAkhir, Integer.parseInt(harga.getText()), Integer.parseInt(penggunaId.getText()), Integer.parseInt(transaksiId.getText()), Integer.parseInt(theatreId.getText()), Integer.parseInt(studioId.getText()), Integer.parseInt(filmId.getText()));
            } catch (SQLIntegrityConstraintViolationException e){
               warningText.setText("Salah Satu ID Tidak ditemukan");
               isValid = false;
            }
            if (isValid){
               HelloApplication app = HelloApplication.getapplicationInstance();
               app.getTiketController().updateTable();
               app.setPrimaryStage(app.getTiket());
            }
         }
      }
   }

   public static boolean isNumeric(String s){
      try {
         Double.parseDouble(s);
         return true;
      } catch (NumberFormatException e){
         return false;
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getTiket());
   }
}


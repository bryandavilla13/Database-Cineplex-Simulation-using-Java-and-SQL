package com.example.proyek.Theatre;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pagination;
import com.example.proyek.Pengguna.Pengguna;
import com.example.proyek.Pengguna.PenggunaProperty;
import com.example.proyek.Pengguna.PenggunaRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class TheatreController implements Initializable {
   @FXML
   private Button ButtonNext, ButtonPrev;
   @FXML
   private TableColumn<TheatreProperty, String> ColumnId, ColumnNama, ColumnAlamat, ColumnKota, ColumnJumlahStudio;
   @FXML
   private TableView<TheatreProperty> TableViewTheatre;
   private int page = 1;

   private int rowsPerPage = 12;

   private ObservableList<TheatreProperty> theatres = FXCollections.observableArrayList();

   private TheatreRepository theatreRepository = new TheatreRepository();

   public TheatreController() throws SQLException {
   }

   @FXML
   void onNextButtonClick(ActionEvent event) throws SQLException {
      page++;
      updateTable();
   }

   @FXML
   void onPrevButtonClick(ActionEvent event) throws SQLException {
      page--;
      updateTable();
   }
   @FXML
   void onBackButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getMenu());
   }
   @FXML
   void onAddButtonClick(){
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.setPrimaryStage(app.getTheatreInsert());
   }

   @FXML
   void onEditButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getTheatreUpdate());
   }

   @FXML
   void onDeleteButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getTheatreDelete());
   }

   private void updateButton() throws SQLException {
      if(page <= 1){
         ButtonPrev.setDisable(true);
      } else {
         ButtonPrev.setDisable(false);
      }
      if (page >= Math.ceil((theatreRepository.GetTheatreCount() / Double.valueOf(rowsPerPage)))){
         ButtonNext.setDisable(true);
      } else {
         ButtonNext.setDisable(false);
      }
   }

   public void updateTable() throws SQLException {
      theatres = FXCollections.observableArrayList();
      ArrayList<Theatre> result;
      try {
         result = theatreRepository.GetTheatre(new Pagination(page, rowsPerPage));
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      result.forEach((t) -> {
         TheatreProperty tp = new TheatreProperty();
         tp.setId(Integer.toString(t.id));
         tp.setNama(t.nama);
         tp.setAlamat(t.alamat);
         tp.setKota(t.kota);
         tp.setJumlahStudio(Integer.toString(t.jumlahStudio));
         theatres.add(tp);
      });
      TableViewTheatre.setItems(theatres);
      updateButton();
   }

   @Override
   public void initialize(URL url, ResourceBundle resourceBundle) {
      ColumnId.setCellValueFactory(f -> f.getValue().IdProperty());
      ColumnNama.setCellValueFactory(f -> f.getValue().NamaProperty());
      ColumnAlamat.setCellValueFactory(f -> f.getValue().AlamatProperty());
      ColumnKota.setCellValueFactory(f -> f.getValue().KotaProperty());
      ColumnJumlahStudio.setCellValueFactory(f -> f.getValue().JumlahStudioProperty());
      try {
         updateTable();
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }
}

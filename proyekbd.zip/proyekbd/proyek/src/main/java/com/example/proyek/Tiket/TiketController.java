package com.example.proyek.Tiket;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pagination;
import com.example.proyek.Transaksi.Transaksi;
import com.example.proyek.Transaksi.TransaksiProperty;
import com.example.proyek.Transaksi.TransaksiRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class TiketController implements Initializable {
   @FXML
   private Button ButtonNext, ButtonPrev;
   @FXML
   private TableColumn<TiketProperty, String> ColumnId, ColumnTanggal, ColumnHarga, ColumnPenggunaId, ColumnTransaksiId, ColumnTheatreId, ColumnStudioId, ColumnFilmId;
   @FXML
   private TableView<TiketProperty> TableViewTiket;

   private int page = 1;

   private int rowsPerPage = 12;

   private ObservableList<TiketProperty> tikets = FXCollections.observableArrayList();

   private TiketRepository tiketRepository = new TiketRepository();

   public TiketController() throws SQLException {
   }

   @FXML
   void onNextButtonClick(ActionEvent event) throws SQLException {
      page++;
      updateTable();
   }

   @FXML
   void onPrevButtonClick(ActionEvent event) throws SQLException {
      page--;
      updateTable();
   }

   @FXML
   void onBackButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getMenu());
   }

   @FXML
   void onAddButtonClick(){
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.setPrimaryStage(app.getTiketInsert());
   }

   @FXML
   void onEditButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getTiketUpdate());
   }

   @FXML
   void onDeleteButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getTiketDelete());
   }

   private void updateButton() throws SQLException {
      if(page <= 1){
         ButtonPrev.setDisable(true);
      } else {
         ButtonPrev.setDisable(false);
      }
      if (page >= Math.ceil((tiketRepository.GetTiketCount() / Double.valueOf(rowsPerPage)))){
         ButtonNext.setDisable(true);
      } else {
         ButtonNext.setDisable(false);
      }
   }

   public void updateTable() throws SQLException {
      tikets = FXCollections.observableArrayList();
      ArrayList<Tiket> result;
      try {
         result = tiketRepository.GetTiket(new Pagination(page, rowsPerPage));
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      result.forEach((t) -> {
         TiketProperty tp = new TiketProperty();
         tp.setId(Integer.toString(t.id));
         tp.setTanggal(t.tanggal);
         tp.setHarga(Integer.toString(t.harga));
         tp.setPenggunaId(Integer.toString(t.penggunaId));
         tp.setTransaksiId(Integer.toString(t.transaksiId));
         tp.setTheatreId(Integer.toString(t.theatreId));
         tp.setStudioId(Integer.toString(t.studioId));
         tp.setFilmId(Integer.toString(t.filmId));
         tikets.add(tp);
      });
      TableViewTiket.setItems(tikets);
      updateButton();
   }

   @Override
   public void initialize(URL url, ResourceBundle resourceBundle) {
      ColumnId.setCellValueFactory(f -> f.getValue().IdProperty());
      ColumnTanggal.setCellValueFactory(f -> f.getValue().TanggalProperty());
      ColumnHarga.setCellValueFactory(f -> f.getValue().HargaProperty());
      ColumnPenggunaId.setCellValueFactory(f -> f.getValue().PenggunaIdProperty());
      ColumnTransaksiId.setCellValueFactory(f -> f.getValue().TransaksiIdProperty());
      ColumnTheatreId.setCellValueFactory(f -> f.getValue().TheatreIdProperty());
      ColumnStudioId.setCellValueFactory(f -> f.getValue().StudioIdProperty());
      ColumnFilmId.setCellValueFactory(f -> f.getValue().FilmIdProperty());
      try {
         updateTable();
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }
}


package com.example.proyek.Pengguna;

import com.example.proyek.HelloApplication;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class PenggunaUpdate {
   @FXML
   TextField id, nama, email, number, jumlahUang;
   @FXML
   Label warningText;
   PenggunaRepository penggunaRepository;

   @FXML
   public void onEditButtonClick() throws SQLException {
      penggunaRepository = new PenggunaRepository();
      if (!isNumeric(id.getText())){
         warningText.setText("Id harus angka");
      }
      else if (!isNumeric(number.getText())){
         warningText.setText("Number harus angka");
      }
      else if (!isNumeric(jumlahUang.getText()) || jumlahUang.getText().equals("")){
         warningText.setText("Jumlah Uang harus angka");
      }
      else if (!penggunaRepository.cekId(Integer.parseInt(id.getText()))){
         warningText.setText("Id invalid");
      }
      else {
         penggunaRepository.updateData(Integer.parseInt(id.getText()), nama.getText(), email.getText(), Integer.parseInt(number.getText()), Integer.parseInt(jumlahUang.getText()));
         HelloApplication app = HelloApplication.getapplicationInstance();
         app.getPenggunaController().updateTable();
         app.setPrimaryStage(app.getPengguna());
      }
   }

   public static boolean isNumeric(String s){
      try {
         Double.parseDouble(s);
         return true;
      } catch (NumberFormatException e){
         return false;
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getPengguna());
   }
}
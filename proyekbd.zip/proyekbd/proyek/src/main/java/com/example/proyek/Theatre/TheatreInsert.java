package com.example.proyek.Theatre;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pengguna.PenggunaRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.sql.SQLException;

public class TheatreInsert {
   @FXML
   TextField nama, alamat, kota, jumlahStudio;
   @FXML
   Label warningText;
   TheatreRepository theatreRepository;

   @FXML
   public void onAddButtonClick() throws SQLException {
      theatreRepository = new TheatreRepository();
      if (!isNumeric(jumlahStudio.getText())){
         warningText.setText("Jumlah Studio harus angka");
      }
      else {
         theatreRepository.insertData(nama.getText(), alamat.getText(), kota.getText(), Integer.parseInt(jumlahStudio.getText()));
         HelloApplication app = HelloApplication.getapplicationInstance();
         app.getTheatreController().updateTable();
         app.setPrimaryStage(app.getTheatre());
      }
   }
   public static boolean isNumeric(String s){
      try {
         Double.parseDouble(s);
         return true;
      } catch (NumberFormatException e){
         return false;
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getTheatre());
   }
}

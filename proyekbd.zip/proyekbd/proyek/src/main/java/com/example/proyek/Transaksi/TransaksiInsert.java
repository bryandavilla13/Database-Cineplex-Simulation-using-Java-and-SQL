package com.example.proyek.Transaksi;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pengguna.PenggunaRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

public class TransaksiInsert {
   @FXML
   TextField tanggal, nominal, penggunaId;
   boolean isValid;
   @FXML
   Label warningText;
   TransaksiRepository transaksiRepository;

   @FXML
   public void onAddButtonClick() throws SQLException {
      transaksiRepository = new TransaksiRepository();
      if (!isNumeric(penggunaId.getText())){
         warningText.setText("Pengguna ID harus angka");
      }
      else if (!(tanggal.getText().length() == 10)){
         warningText.setText("Tanggal Invalid");
      }
      else if (!(tanggal.getText().charAt(4) == '-')){
         warningText.setText("Tanggal Invalid");
      }
      else if (!(tanggal.getText().charAt(7) == '-')){
         warningText.setText("Tanggal Invalid");
      }
      else {
         String[] temp = tanggal.getText().split("-");
         String tanggalAkhir = "";
         for (String s : temp) {
            if (!isNumeric(s)) {
               warningText.setText("Tanggal Invalid");
            }
         }
         if (temp.length != 3){
            warningText.setText("Tanggal Invalid");
         }
         else if (Integer.parseInt(temp[1]) > 12 || Integer.parseInt(temp[1]) < 0){
            warningText.setText("Bulan Invalid");
         }
         else if (Integer.parseInt(temp[2]) > 31 || Integer.parseInt(temp[2]) < 0){
            warningText.setText("Bulan Invalid");
         }
         else {
            tanggalAkhir += temp[0] + "-" + temp[1] + "-" + temp[2];
            isValid = true;
            try {
               transaksiRepository.insertData(tanggalAkhir, Integer.parseInt(nominal.getText()), Integer.parseInt(penggunaId.getText()));
            } catch (SQLIntegrityConstraintViolationException e){
               warningText.setText("Pengguna ID Tidak ditemukan");
               isValid = false;
            }
            if (isValid){
               HelloApplication app = HelloApplication.getapplicationInstance();
               app.getTransaksiController().updateTable();
               app.setPrimaryStage(app.getTransaksi());
            }
         }
      }
   }

   public static boolean isNumeric(String s){
      try {
         Double.parseDouble(s);
         return true;
      } catch (NumberFormatException e){
         return false;
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getTransaksi());
   }
}

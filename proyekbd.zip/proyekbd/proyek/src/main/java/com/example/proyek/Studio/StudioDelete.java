package com.example.proyek.Studio;

import com.example.proyek.HelloApplication;
import com.example.proyek.Transaksi.TransaksiRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class StudioDelete {
   @FXML
   TextField id;
   boolean isValid;
   @FXML
   Label warningText;
   StudioRepository studioRepository;

   @FXML
   public void onDeleteButtonClick() throws SQLException {
      studioRepository = new StudioRepository();
      String inputId = id.getText().replace(" ","");
      isValid = true;
      if (inputId.contains(",")){
         String[] temp = inputId.split(",");
         for (String x : temp) {
            if (studioRepository.cekId(Integer.parseInt(x)) && isValid) {
               studioRepository.deleteData(Integer.parseInt(x));
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getStudioController().updateTable();
            app.setPrimaryStage(app.getStudio());
         }
      }
      else if (inputId.contains("-")){
         String[] temp = inputId.split("-");
         for (int i = Integer.parseInt(temp[0]) ; i <= Integer.parseInt(temp[1]) ; i++){
            if (studioRepository.cekId(i) && isValid) {
               studioRepository.deleteData(i);
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getStudioController().updateTable();
            app.setPrimaryStage(app.getStudio());
         }
      }
      else {
         if (studioRepository.cekId(Integer.parseInt(id.getText()))){
            studioRepository.deleteData(Integer.parseInt(id.getText()));
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getStudioController().updateTable();
            app.setPrimaryStage(app.getStudio());
         }
         else {
            warningText.setText("Input Invalid");
         }
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getStudio());
   }
}

package com.example.proyek.Tiket;

import com.example.proyek.HelloApplication;
import com.example.proyek.Transaksi.TransaksiRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class TiketDelete {
   @FXML
   TextField id;
   boolean isValid;
   @FXML
   Label warningText;
   TiketRepository tiketRepository;

   @FXML
   public void onDeleteButtonClick() throws SQLException {
      tiketRepository = new TiketRepository();
      String inputId = id.getText().replace(" ","");
      isValid = true;
      if (inputId.contains(",")){
         String[] temp = inputId.split(",");
         for (String x : temp) {
            if (tiketRepository.cekId(Integer.parseInt(x)) && isValid) {
               tiketRepository.deleteData(Integer.parseInt(x));
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getTiketController().updateTable();
            app.setPrimaryStage(app.getTiket());
         }
      }
      else if (inputId.contains("-")){
         String[] temp = inputId.split("-");
         for (int i = Integer.parseInt(temp[0]) ; i <= Integer.parseInt(temp[1]) ; i++){
            if (tiketRepository.cekId(i) && isValid) {
               tiketRepository.deleteData(i);
            }
            else {
               warningText.setText("Input Invalid");
               isValid = false;
            }
         }
         if (isValid){
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getTiketController().updateTable();
            app.setPrimaryStage(app.getTiket());
         }
      }
      else {
         if (tiketRepository.cekId(Integer.parseInt(id.getText()))){
            tiketRepository.deleteData(Integer.parseInt(id.getText()));
            HelloApplication app = HelloApplication.getapplicationInstance();
            app.getTiketController().updateTable();
            app.setPrimaryStage(app.getTiket());
         }
         else {
            warningText.setText("Input Invalid");
         }
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getTiket());
   }
}

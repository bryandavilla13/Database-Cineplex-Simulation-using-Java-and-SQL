package com.example.proyek.Pengguna;

import com.example.proyek.Pagination;
import com.example.proyek.connection;

import java.sql.*;
import java.time.temporal.JulianFields;
import java.util.ArrayList;

public class PenggunaRepository {
   private Connection conn;

   public PenggunaRepository() throws SQLException {
      conn = connection.GetConnection();
   }

   public int GetPenggunaCount() throws SQLException {
      Statement stmt = conn.createStatement();
      String sql = "SELECT COUNT(id) FROM pengguna";
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      if (rs.next()) {
         return rs.getInt(1);
      } else {
         return 0;
      }
   }

   public ArrayList<Pengguna> GetPengguna(Pagination pgn) throws SQLException {
      ArrayList<Pengguna> penggunas = new ArrayList<Pengguna>();
      Statement stmt = conn.createStatement();
      String sql = String.format("SELECT * FROM pengguna LIMIT %o OFFSET %o", pgn.limit, pgn.offset);
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()) {
         penggunas.add(
                 new Pengguna(
                         rs.getInt("id"),
                         rs.getString("nama"),
                         rs.getString("email"),
                         rs.getInt("number"),
                         rs.getInt("jumlah_uang")
                 )
         );
      }
      return penggunas;
   }

   public void insertData(String nama, String email, int number, int jumlahUang) {
      String Query = "INSERT INTO pengguna (nama, email, number, jumlah_uang) VALUES (?,?,?,?)";
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         preparedStatement.setString(1, nama);
         preparedStatement.setString(2, email);
         preparedStatement.setString(3, String.valueOf(number));
         preparedStatement.setString(4, String.valueOf(jumlahUang));

         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e) {
         System.out.println(e);
      }
   }

   public void updateData(int id, String nama, String email, int number, int jumlahUang) {
      String Query = "UPDATE pengguna SET ";
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query + "nama = '" + nama + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();
         preparedStatement = conn.prepareStatement(Query + "email = '" + email + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();
         preparedStatement = conn.prepareStatement(Query + "number = '" + number + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();
         preparedStatement = conn.prepareStatement(Query + "jumlah_uang = '" + jumlahUang + "' where id = " + id);
         System.out.println(preparedStatement);
         preparedStatement.execute();

         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e) {
         System.out.println(e);
      }
   }

   public void deleteData(int id) {
      String Query = "DELETE FROM pengguna WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e) {
         System.out.println(e);
      }
   }

   public boolean cekId(int id) {
      String Query = "select * FROM pengguna WHERE id = " + id;
      try {
         PreparedStatement preparedStatement = conn.prepareStatement(Query);
         System.out.println(preparedStatement);
         preparedStatement.execute();
      } catch (SQLException e) {
         return false;
      }
      return true;
   }

   public ArrayList<Pengguna> GetMostBuy(Pagination pgn) throws SQLException {
      ArrayList<Pengguna> penggunas = new ArrayList<Pengguna>();
      Statement stmt = conn.createStatement();
      String sql = String.format("SELECT p.id, p.nama, p.email, p.number, p.jumlah_uang \n" +
              "FROM pengguna p\n" +
              "join transaksi t on t.pengguna_id = p.id\n" +
              "GROUP by p.id\n" +
              "ORDER BY count(t.id) DESC LIMIT %o OFFSET %o", pgn.limit, pgn.offset);
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()) {
         penggunas.add(
                 new Pengguna(
                         rs.getInt("id"),
                         rs.getString("nama"),
                         rs.getString("email"),
                         rs.getInt("number"),
                         rs.getInt("jumlah_uang")
                 )
         );
      }
      return penggunas;
   }
}


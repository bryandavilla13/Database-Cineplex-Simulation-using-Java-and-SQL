package com.example.proyek.Film;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pengguna.PenggunaRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class FilmInsert {
   @FXML
   TextField nama, durasi, genre, sutradara;
   @FXML
   Label warningText;
   FilmRepository filmRepository;

   @FXML
   public void onAddButtonClick() throws SQLException {
      filmRepository = new FilmRepository();
      if (!isNumeric(durasi.getText())){
         warningText.setText("Durasi harus angka");
      }
      else {
         filmRepository.insertData(nama.getText(), Integer.parseInt(durasi.getText()), genre.getText(), sutradara.getText());
         HelloApplication app = HelloApplication.getapplicationInstance();
         app.getFilmController().updateTable();
         app.setPrimaryStage(app.getFilm());
      }
   }

   public static boolean isNumeric(String s){
      try {
         Double.parseDouble(s);
         return true;
      } catch (NumberFormatException e){
         return false;
      }
   }
   @FXML
   void onBackButtonClick() throws SQLException {
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.getFilmController().updateTable();
      app.setPrimaryStage(app.getFilm());
   }
}

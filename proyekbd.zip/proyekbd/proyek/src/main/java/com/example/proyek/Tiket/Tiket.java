package com.example.proyek.Tiket;

public class Tiket {
   int id, harga, penggunaId, transaksiId, filmId, studioId, theatreId;
   String tanggal;

   public Tiket(int id, String tanggal, int harga, int penggunaId, int transaksiId, int theatreId, int studioId, int filmId) {
      this.id = id;
      this.harga = harga;
      this.penggunaId = penggunaId;
      this.transaksiId = transaksiId;
      this.filmId = filmId;
      this.studioId = studioId;
      this.theatreId = theatreId;
      this.tanggal = tanggal;
   }
}

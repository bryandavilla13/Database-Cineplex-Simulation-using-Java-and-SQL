package com.example.proyek;

public class Menu {
   public void onPenggunaButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getPengguna());
   }
   public void onTheatreButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getTheatre());
   }

   public void onFilmButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getFilm());
   }

   public void onTransaksiButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getTransaksi());
   }

   public void onStudioButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getStudio());
   }

   public void onTiketButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getTiket());
   }

   public void onAnalisisButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getAnalisis());
   }
}

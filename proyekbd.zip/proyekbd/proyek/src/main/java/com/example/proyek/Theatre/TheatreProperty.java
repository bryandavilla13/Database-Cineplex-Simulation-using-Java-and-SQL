package com.example.proyek.Theatre;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class TheatreProperty {
   private final StringProperty id;
   private final StringProperty nama;
   private final StringProperty alamat;
   private final StringProperty kota;
   private final StringProperty jumlahStudio;

   public TheatreProperty(){
      id = new SimpleStringProperty(this, "id");
      nama = new SimpleStringProperty(this, "nama");
      alamat = new SimpleStringProperty(this, "alamat");
      kota = new SimpleStringProperty(this, "kota");
      jumlahStudio = new SimpleStringProperty(this, "jumlah_studio");
   }

   public StringProperty IdProperty(){return id;}
   public String getId(){return IdProperty().get();}
   public void setId(String newId){id.set(newId);}

   public StringProperty NamaProperty(){return nama;}
   public String getNama(){return NamaProperty().get();}
   public void setNama(String newNama){nama.set(newNama);}

   public StringProperty AlamatProperty(){return alamat;}
   public String getAlamat(){return AlamatProperty().get();}
   public void setAlamat(String newAlamat){alamat.set(newAlamat);}

   public StringProperty KotaProperty(){return kota;}
   public String getKota(){return KotaProperty().get();}
   public void setKota(String newKota){kota.set(newKota);}

   public StringProperty JumlahStudioProperty(){return jumlahStudio;}
   public String getJumlahStudio(){return JumlahStudioProperty().get();}
   public void setJumlahStudio(String newJumlahStudio){jumlahStudio.set(newJumlahStudio);}
}

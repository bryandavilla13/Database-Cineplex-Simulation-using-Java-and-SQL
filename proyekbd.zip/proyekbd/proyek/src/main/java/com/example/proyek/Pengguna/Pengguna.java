package com.example.proyek.Pengguna;

public class Pengguna {
   public int id;
   public int number;
   public int jumlah_uang;
   public String nama;
   public String email;

   public Pengguna(int id, String nama, String email, int number, int jumlah_uang) {
      this.id = id;
      this.number = number;
      this.jumlah_uang = jumlah_uang;
      this.nama = nama;
      this.email = email;
   }
}

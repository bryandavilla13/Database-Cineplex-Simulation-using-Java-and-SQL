package com.example.proyek.Transaksi;

import com.example.proyek.HelloApplication;
import com.example.proyek.Pagination;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class TransaksiController implements Initializable {
   @FXML
   private Button ButtonNext, ButtonPrev;
   @FXML
   private TableColumn<TransaksiProperty, String> ColumnId, ColumnTanggal, ColumnNominal, ColumnPenggunaId;
   @FXML
   private TableView<TransaksiProperty> TableViewTransaksi;

   private int page = 1;

   private int rowsPerPage = 12;

   private ObservableList<TransaksiProperty> transaksis = FXCollections.observableArrayList();

   private TransaksiRepository transaksiRepository = new TransaksiRepository();

   public TransaksiController() throws SQLException {
   }

   @FXML
   void onNextButtonClick(ActionEvent event) throws SQLException {
      page++;
      updateTable();
   }

   @FXML
   void onPrevButtonClick(ActionEvent event) throws SQLException {
      page--;
      updateTable();
   }

   @FXML
   void onBackButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getMenu());
   }

   @FXML
   void onAddButtonClick(){
      HelloApplication app = HelloApplication.getapplicationInstance();
      app.setPrimaryStage(app.getTransaksiInsert());
   }

   @FXML
   void onEditButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getTransaksiUpdate());
   }

   @FXML
   void onDeleteButtonClick(){
      HelloApplication app = HelloApplication.getApplicationInstance();
      app.setPrimaryStage(app.getTransaksiDelete());
   }

   private void updateButton() throws SQLException {
      if(page <= 1){
         ButtonPrev.setDisable(true);
      } else {
         ButtonPrev.setDisable(false);
      }
      if (page >= Math.ceil((transaksiRepository.GetTransaksiCount() / Double.valueOf(rowsPerPage)))){
         ButtonNext.setDisable(true);
      } else {
         ButtonNext.setDisable(false);
      }
   }

   public void updateTable() throws SQLException {
      transaksis = FXCollections.observableArrayList();
      ArrayList<Transaksi> result;
      try {
         result = transaksiRepository.GetTransaksi(new Pagination(page, rowsPerPage));
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      result.forEach((t) -> {
         TransaksiProperty tp = new TransaksiProperty();
         tp.setId(Integer.toString(t.id));
         tp.setTanggal(t.tanggal);
         tp.setNominal(Integer.toString(t.nominal));
         tp.setPenggunaId(Integer.toString(t.penggunaId));
         transaksis.add(tp);
      });
      TableViewTransaksi.setItems(transaksis);
      updateButton();
   }

   @Override
   public void initialize(URL url, ResourceBundle resourceBundle) {
      ColumnId.setCellValueFactory(f -> f.getValue().IdProperty());
      ColumnTanggal.setCellValueFactory(f -> f.getValue().TanggalProperty());
      ColumnNominal.setCellValueFactory(f -> f.getValue().NominalProperty());
      ColumnPenggunaId.setCellValueFactory(f -> f.getValue().PenggunaIdProperty());
      try {
         updateTable();
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }
}

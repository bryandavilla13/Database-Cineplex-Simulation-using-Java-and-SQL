module com.example.proyek {
   requires javafx.controls;
   requires javafx.fxml;
   requires java.sql;
   requires io.github.cdimascio.dotenv.java;

   exports com.example.proyek;
   exports com.example.proyek.Pengguna;
   exports com.example.proyek.Theatre;
   exports com.example.proyek.Film;
   exports com.example.proyek.Transaksi;
   exports com.example.proyek.Studio;
   exports com.example.proyek.Tiket;

   opens com.example.proyek to javafx.fxml;
   opens com.example.proyek.Pengguna to javafx.fxml;
   opens com.example.proyek.Theatre to javafx.fxml;
   opens com.example.proyek.Film to javafx.fxml;
   opens com.example.proyek.Transaksi to javafx.fxml;
   opens com.example.proyek.Studio to javafx.fxml;
   opens com.example.proyek.Tiket to javafx.fxml;
}